package com.example.gameboost

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import android.view.animation.DecelerateInterpolator
import kotlin.math.abs

/** Bar tipis rounded ala iOS; nilainya bergerak halus ke target (animasi hanya saat nilai berubah). */
class GlowBar @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null) : View(context, attrs) {

    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF2C2C2E.toInt() }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private var shown = 0f
    private var color = 0xFFFF2D3F.toInt()
    private var anim: ValueAnimator? = null

    fun setValue(target: Float, newColor: Int) {
        val t = target.coerceIn(0f, 1f)
        if (newColor != color) { color = newColor; rebuild() }
        if (abs(t - shown) < 0.002f) return
        anim?.cancel()
        anim = ValueAnimator.ofFloat(shown, t).apply {
            duration = 600
            interpolator = DecelerateInterpolator()
            addUpdateListener { shown = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    private fun rebuild() {
        if (width <= 0) return
        fill.shader = LinearGradient(0f, 0f, width.toFloat(), 0f, (color and 0x00FFFFFF) or 0x80000000.toInt(), color, Shader.TileMode.CLAMP)
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) { super.onSizeChanged(w, h, ow, oh); rebuild() }
    override fun onDetachedFromWindow() { anim?.cancel(); super.onDetachedFromWindow() }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        rect.set(0f, 0f, w, h); canvas.drawRoundRect(rect, h / 2, h / 2, track)
        val fw = (w * shown).coerceAtLeast(if (shown > 0f) h else 0f)
        if (fw > 0f) { rect.set(0f, 0f, fw, h); canvas.drawRoundRect(rect, h / 2, h / 2, fill) }
    }
}
