package com.example.gameboost

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PathMeasure
import android.graphics.RectF
import android.os.SystemClock
import android.util.AttributeSet
import android.widget.LinearLayout
import kotlin.random.Random

/** Kartu rounded ala iOS + cahaya merah ala ROG yang berjalan mengelilingi tepinya. */
class GlowCard @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null) : LinearLayout(context, attrs) {

    private val d = resources.displayMetrics.density
    private val r = 20f * d
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = 0xD01C1C1E.toInt() }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = d; color = 0xFF38383A.toInt() }
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 5f * d; strokeCap = Paint.Cap.ROUND; color = 0x40FF2D3F
    }
    private val core = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 1.6f * d; strokeCap = Paint.Cap.ROUND; color = 0xFFFF5468.toInt()
    }
    private val rect = RectF()
    private val path = Path()
    private val seg = Path()
    private val pm = PathMeasure()
    private val offset = Random.nextFloat()

    init { setWillNotDraw(false) }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        rect.set(d, d, w - d, h - d)
        path.reset(); path.addRoundRect(rect, r, r, Path.Direction.CW)
        pm.setPath(path, false)
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawRoundRect(rect, r, r, fill)
        canvas.drawRoundRect(rect, r, r, stroke)
        super.onDraw(canvas)
    }

    override fun dispatchDraw(canvas: Canvas) {
        super.dispatchDraw(canvas)
        val len = pm.length
        if (width > 0 && len > 0f) {
            val phase = (((SystemClock.uptimeMillis() % 3600L) / 3600f) + offset) % 1f
            val s = phase * len; val l = len * 0.16f
            seg.reset()
            if (s + l <= len) pm.getSegment(s, s + l, seg, true)
            else { pm.getSegment(s, len, seg, true); pm.getSegment(0f, s + l - len, seg, false) }
            canvas.drawPath(seg, glow)
            canvas.drawPath(seg, core)
        }
        if (isShown) postInvalidateOnAnimation()
    }
}
