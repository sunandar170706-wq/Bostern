package com.example.gameboost

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.util.AttributeSet
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/**
 * Intro ROG x cyberpunk: scan beam, grid lantai perspektif, hujan neon, logo glitch RGB-split,
 * HUD sudut, teks boot ala terminal dan progress bar bersegmen. Ketuk untuk lewati.
 */
class IntroView @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null) : View(context, attrs) {

    private val d = resources.displayMetrics.density
    private val total = 3000L
    private val logo: Bitmap? = BitmapFactory.decodeResource(resources, R.drawable.logo_bostern)
    private var p = 0f
    private var anim: ValueAnimator? = null
    private var finished = false

    private val red = 0xFFFF2D3F.toInt()
    private val ok = 0xFF30D158.toInt()
    private val dim = 0xFF8E8E93.toInt()

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeWidth = d }
    private val hud = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeWidth = 2f * d; color = red; strokeCap = Paint.Cap.SQUARE }
    private val scanPaint = Paint().apply { color = 0x0EFFFFFF; strokeWidth = 1f }
    private val logoPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val ghostR = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
        xfermode = PorterDuffXfermode(PorterDuff.Mode.ADD)
        colorFilter = ColorMatrixColorFilter(ColorMatrix(floatArrayOf(1f,0f,0f,0f,0f, 0f,0f,0f,0f,0f, 0f,0f,0f,0f,0f, 0f,0f,0f,1f,0f)))
    }
    private val ghostC = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
        xfermode = PorterDuffXfermode(PorterDuff.Mode.ADD)
        colorFilter = ColorMatrixColorFilter(ColorMatrix(floatArrayOf(0f,0f,0f,0f,0f, 0f,1f,0f,0f,0f, 0f,0f,1f,0f,0f, 0f,0f,0f,1f,0f)))
    }
    private val mono = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.create("monospace", Typeface.NORMAL); textSize = 11.5f * d; color = 0xFFCFCFD6.toInt()
    }
    private val monoB = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.create("monospace", Typeface.BOLD); textSize = 11.5f * d
    }
    private val title = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD_ITALIC); textSize = 13f * d
        letterSpacing = 0.4f; textAlign = Paint.Align.CENTER; color = dim
    }
    private val byPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD_ITALIC); textSize = 17f * d; letterSpacing = 0.25f
    }

    private val dest = RectF()
    private val bar = RectF()
    private var glow: RadialGradient? = null
    private var vignette: RadialGradient? = null
    private var glowR = 0f
    private var beamH = 0f
    private val beam = Paint()
    private var scan = FloatArray(0)

    private val rainN = 16
    private val rx = FloatArray(rainN); private val ry = FloatArray(rainN)
    private val rs = FloatArray(rainN); private val rl = FloatArray(rainN)

    private val names = arrayOf("ROG ENGINE", "RAM CLEANER", "THERMAL GUARD", "GAME MODE")
    private val status = arrayOf("ONLINE", "OK", "OK", "ARMED")
    private val prefix = names.map { ("> $it ").padEnd(24, '.') + " " }

    private fun smooth(x: Float): Float { val t = x.coerceIn(0f, 1f); return t * t * (3f - 2f * t) }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        glowR = min(w, h) * 0.65f
        glow = RadialGradient(0f, 0f, glowR, 0x66FF2D3F, 0x00FF2D3F, Shader.TileMode.CLAMP)
        vignette = RadialGradient(w / 2f, h / 2f, maxOf(w, h) * 0.75f, 0x00000000, 0xCC000000.toInt(), Shader.TileMode.CLAMP)
        beamH = 70f * d
        beam.shader = LinearGradient(0f, 0f, 0f, beamH, intArrayOf(0x00FF2D3F, 0x88FF2D3F.toInt(), 0x00FF2D3F), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
        val n = (h / (3f * d)).toInt()
        scan = FloatArray(n * 4) { i -> when (i % 4) { 0 -> 0f; 2 -> w.toFloat(); else -> (i / 4) * 3f * d } }
        val r = Random(7)
        for (i in 0 until rainN) {
            rx[i] = r.nextFloat() * w; ry[i] = r.nextFloat(); rs[i] = 0.25f + r.nextFloat() * 0.5f; rl[i] = 30f + r.nextFloat() * 70f
        }
    }

    /** Jalankan intro. [onStartExit] dipanggil begitu intro mulai menghilang. */
    fun play(onStartExit: () -> Unit) {
        isClickable = true
        val a = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = total
            interpolator = LinearInterpolator()
            addUpdateListener { p = it.animatedValue as Float; invalidate() }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    if (finished) return
                    finished = true
                    onStartExit()
                    animate().alpha(0f).scaleX(1.08f).scaleY(1.08f).setDuration(380)
                        .withEndAction { visibility = GONE }.start()
                }
            })
        }
        anim = a
        setOnClickListener { a.end() }   // ketuk untuk lewati
        a.start()
    }

    override fun onDetachedFromWindow() { anim?.cancel(); super.onDetachedFromWindow() }

    private fun glitch(p: Float): Float {
        var g = 0f
        if (p in 0.10f..0.42f) g = 1f - (p - 0.10f) / 0.32f
        if (p in 0.60f..0.64f || p in 0.82f..0.85f) g = maxOf(g, 0.55f)
        return g
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val t = p * total / 1000f
        c.drawColor(0xFF050507.toInt())
        val cx = w / 2f; val cy = h * 0.32f

        // ---- grid lantai perspektif ----
        val hor = h * 0.58f
        val fade = smooth(p / 0.25f)
        for (i in -9..9) {
            val a = (fade * (1f - abs(i) / 11f) * 150f).toInt().coerceIn(0, 255)
            line.color = (a shl 24) or 0x00FF2D3F
            c.drawLine(cx + i * 14f * d, hor, cx + i * 62f * d, h, line)
        }
        val n = 9
        for (k in 0 until n) {
            val tt = ((k + p * 6f) % n) / n
            line.color = ((fade * tt * 170f).toInt().coerceIn(0, 255) shl 24) or 0x00FF2D3F
            val y = hor + (h - hor) * tt * tt
            c.drawLine(0f, y, w, y, line)
        }
        line.color = ((fade * 230f).toInt().coerceIn(0, 255) shl 24) or 0x00FF2D3F
        c.drawLine(0f, hor, w, hor, line)

        // ---- hujan neon ----
        val ra = smooth(p / 0.2f) * (1f - smooth((p - 0.8f) / 0.2f))
        for (i in 0 until rainN) {
            val y = ((ry[i] + t * rs[i]) % 1.25f - 0.1f) * h
            line.color = ((110f * ra).toInt() shl 24) or 0x00FF2D3F
            c.drawLine(rx[i], y - rl[i] * d, rx[i], y, line)
            line.color = ((230f * ra).toInt() shl 24) or 0x00FFFFFF
            c.drawLine(rx[i], y - 6f * d, rx[i], y, line)
        }

        // ---- glow di belakang logo ----
        val e = smooth((p - 0.10f) / 0.18f)
        glow?.let {
            fill.shader = it; fill.alpha = (255 * e * (0.8f + 0.2f * sin(p * 14f))).toInt().coerceIn(0, 255)
            c.save(); c.translate(cx, cy); c.drawCircle(0f, 0f, glowR, fill); c.restore()
            fill.shader = null; fill.alpha = 255
        }

        // ---- beam scan ----
        if (p in 0.04f..0.55f) {
            val y = h * ((p - 0.04f) / 0.51f)
            c.save(); c.translate(0f, y - beamH / 2f); c.drawRect(0f, 0f, w, beamH, beam); c.restore()
        }

        // ---- logo + glitch RGB split ----
        val size = min(w, h) * 0.50f * (0.8f + 0.2f * e)
        dest.set(cx - size / 2f, cy - size / 2f, cx + size / 2f, cy + size / 2f)
        logo?.let { b ->
            val g = glitch(p)
            val rnd = Random((p * 60f).toInt())
            if (g > 0.05f) {
                val dx = g * 12f * d * (0.5f + rnd.nextFloat())
                ghostR.alpha = (220 * e).toInt(); c.save(); c.translate(-dx, 0f); c.drawBitmap(b, null, dest, ghostR); c.restore()
                ghostC.alpha = (220 * e).toInt(); c.save(); c.translate(dx, 0f); c.drawBitmap(b, null, dest, ghostC); c.restore()
            }
            logoPaint.alpha = (255 * e * (1f - 0.35f * g)).toInt().coerceIn(0, 255)
            c.drawBitmap(b, null, dest, logoPaint)
            if (g > 0.2f) for (k in 0..2) {
                val sy = dest.top + rnd.nextFloat() * dest.height() * 0.9f
                val sh = (6f + rnd.nextFloat() * 16f) * d
                val sdx = (rnd.nextFloat() - 0.5f) * 40f * d * g
                c.save(); c.clipRect(dest.left, sy, dest.right, sy + sh); c.translate(sdx, 0f)
                c.drawBitmap(b, null, dest, logoPaint); c.restore()
            }
        }

        // ---- vignette + scanlines CRT ----
        vignette?.let { fill.shader = it; c.drawRect(0f, 0f, w, h, fill); fill.shader = null }
        c.drawLines(scan, scanPaint)

        // ---- HUD sudut ----
        val m = 16f * d
        val lb = 30f * d * smooth((p - 0.18f) / 0.2f)
        hud.alpha = 220
        c.drawLine(m, m, m + lb, m, hud); c.drawLine(m, m, m, m + lb, hud)
        c.drawLine(w - m, m, w - m - lb, m, hud); c.drawLine(w - m, m, w - m, m + lb, hud)
        c.drawLine(m, h - m, m + lb, h - m, hud); c.drawLine(m, h - m, m, h - m - lb, hud)
        c.drawLine(w - m, h - m, w - m - lb, h - m, hud); c.drawLine(w - m, h - m, w - m, h - m - lb, hud)
        val ha = smooth((p - 0.3f) / 0.15f)
        if (ha > 0f) {
            mono.alpha = (160 * ha).toInt(); mono.textSize = 9.5f * d
            c.drawText("SYS://BOSTERn", m + 6f * d, m + 24f * d, mono)
            mono.textAlign = Paint.Align.RIGHT; c.drawText("NODE 01", w - m - 6f * d, m + 24f * d, mono)
            mono.textAlign = Paint.Align.LEFT; mono.textSize = 11.5f * d; mono.alpha = 255
        }

        // ---- judul ----
        title.alpha = (255 * smooth((p - 0.30f) / 0.15f)).toInt()
        c.drawText("GAME BOOSTER", cx, dest.bottom + 26f * d, title)

        // ---- teks boot ala terminal ----
        val tw = mono.measureText(prefix[0] + status[0])
        val x0 = (w - tw) / 2f
        val y0 = dest.bottom + 62f * d
        var active = -1
        for (i in prefix.indices) {
            val frac = ((p - (0.40f + i * 0.10f)) / 0.09f).coerceIn(0f, 1f)
            if (frac <= 0f) continue
            active = i
            val cnt = (frac * prefix[i].length).toInt()
            val y = y0 + i * 18f * d
            c.drawText(prefix[i].take(cnt), x0, y, mono)
            if (frac >= 1f) {
                monoB.color = if (i == 3) red else ok
                c.drawText(status[i], x0 + mono.measureText(prefix[i]), y, monoB)
            }
        }
        if (active >= 0 && ((t * 4f).toInt() % 2 == 0)) {
            val frac = ((p - (0.40f + active * 0.10f)) / 0.09f).coerceIn(0f, 1f)
            val cnt = (frac * prefix[active].length).toInt()
            var xx = x0 + mono.measureText(prefix[active].take(cnt))
            if (frac >= 1f) xx += monoB.measureText(status[active]) + 4f * d
            c.drawText("_", xx, y0 + active * 18f * d, mono)
        }

        // ---- progress bar bersegmen ----
        val seg = 20
        val bx = w * 0.15f; val bwid = w * 0.70f; val by0 = h - 78f * d
        val gap = 3f * d; val sw = (bwid - (seg - 1) * gap) / seg
        val filled = p * seg
        for (i in 0 until seg) {
            val f = (filled - i).coerceIn(0f, 1f)
            bar.set(bx + i * (sw + gap), by0, bx + i * (sw + gap) + sw, by0 + 7f * d)
            fill.color = 0xFF1B1B21.toInt(); c.drawRoundRect(bar, 1.5f * d, 1.5f * d, fill)
            if (f > 0f) { fill.color = red; fill.alpha = (255 * f).toInt(); c.drawRoundRect(bar, 1.5f * d, 1.5f * d, fill) }
        }
        fill.alpha = 255
        mono.textSize = 10f * d; mono.color = dim
        c.drawText("SYSTEM LOADING", bx, by0 - 8f * d, mono)
        mono.textAlign = Paint.Align.RIGHT; c.drawText("${(p * 100f).toInt()}%", bx + bwid, by0 - 8f * d, mono)
        mono.textAlign = Paint.Align.LEFT; mono.textSize = 11.5f * d; mono.color = 0xFFCFCFD6.toInt()

        // ---- BY nandar ----
        val ta = smooth((p - 0.72f) / 0.12f)
        if (ta > 0f) {
            val wa = byPaint.measureText("BY"); val wb = byPaint.measureText("nandar"); val g2 = 8f * d
            val bx2 = cx - (wa + g2 + wb) / 2f; val yy = h - 36f * d
            byPaint.alpha = (255 * ta).toInt()
            byPaint.color = red; byPaint.alpha = (255 * ta).toInt(); c.drawText("BY", bx2, yy, byPaint)
            byPaint.color = 0xFFFFFFFF.toInt(); byPaint.alpha = (255 * ta).toInt(); c.drawText("nandar", bx2 + wa + g2, yy, byPaint)
        }
        title.alpha = 120; title.textSize = 9f * d
        c.drawText("KETUK UNTUK LEWATI", cx, h - 14f * d, title)
        title.textSize = 13f * d

        // ---- flash saat masuk ----
        if (p > 0.95f) {
            fill.color = 0xFFFF2D3F.toInt(); fill.alpha = (((p - 0.95f) / 0.05f) * 60f).toInt()
            c.drawRect(0f, 0f, w, h, fill); fill.alpha = 255
        }
    }
}
