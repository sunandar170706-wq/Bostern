package com.example.gameboost

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Shader
import android.os.SystemClock
import android.util.AttributeSet
import androidx.appcompat.widget.AppCompatTextView

/** Teks dengan kilau putih yang menyapu berulang (dipakai untuk "BY nandar"). */
class ShimmerTextView @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null) : AppCompatTextView(context, attrs) {

    private var shader: LinearGradient? = null
    private val m = Matrix()
    private val baseColor = 0xFFFF2D3F.toInt()

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        if (w > 0) {
            shader = LinearGradient(
                0f, 0f, w.toFloat(), 0f,
                intArrayOf(baseColor, baseColor, 0xFFFFFFFF.toInt(), baseColor, baseColor),
                floatArrayOf(0f, 0.35f, 0.5f, 0.65f, 1f), Shader.TileMode.CLAMP
            )
        }
    }

    override fun onDraw(canvas: Canvas) {
        val s = shader
        if (s != null) {
            val w = width.toFloat()
            val x = ((SystemClock.uptimeMillis() % 2600L) / 2600f) * (2f * w) - w
            m.setTranslate(x, 0f); s.setLocalMatrix(m)
            paint.shader = s
        }
        super.onDraw(canvas)
        if (isShown) postInvalidateOnAnimation()
    }
}
