package com.example.gameboost

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.graphics.Typeface
import android.os.SystemClock
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.view.animation.OvershootInterpolator
import androidx.core.content.ContextCompat
import kotlin.math.sin

/** Tombol BOOST: glow berdenyut, kilau menyapu, cincin cahaya berputar. Ikon pakai vector (bukan emoji). */
class BoostButton @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null) : View(context, attrs) {

    private enum class S { IDLE, BUSY, DONE }

    private val d = resources.displayMetrics.density
    private var state = S.IDLE
    private var label = "BOOST"
    private var doneUntil = 0L
    private var angle = 0f
    private var lastT = SystemClock.uptimeMillis()

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val shine = Paint(Paint.ANTI_ALIAS_FLAG)
    private val border = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2f * d }
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textSize = 19f * d; letterSpacing = 0.14f
        typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD_ITALIC)
    }
    private val bolt = ContextCompat.getDrawable(context, R.drawable.ic_bolt)!!.mutate()
    private val check = ContextCompat.getDrawable(context, R.drawable.ic_check)!!.mutate()
    private val rect = RectF()
    private val clip = Path()
    private val band = Path()
    private val m = Matrix()
    private var red: Shader? = null
    private var green: Shader? = null
    private var sweep: SweepGradient? = null
    private var bw = 0f
    private var sk = 0f

    init { isClickable = true }

    fun start() { state = S.BUSY; label = "MEMBERSIHKAN" }

    fun finish(result: String) {
        state = S.DONE; label = result
        doneUntil = SystemClock.uptimeMillis() + 2200L
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        val wf = w.toFloat(); val hf = h.toFloat()
        rect.set(6f * d, 6f * d, wf - 6f * d, hf - 6f * d)
        clip.reset(); clip.addRoundRect(rect, 18f * d, 18f * d, Path.Direction.CW)
        red = LinearGradient(0f, 0f, wf, 0f, 0xFFFF2D3F.toInt(), 0xFF9E0018.toInt(), Shader.TileMode.CLAMP)
        green = LinearGradient(0f, 0f, wf, 0f, 0xFF30D158.toInt(), 0xFF1B8A3A.toInt(), Shader.TileMode.CLAMP)
        sweep = SweepGradient(
            wf / 2f, hf / 2f,
            intArrayOf(0x00FFFFFF, 0x00FFFFFF, 0xCCFFFFFF.toInt(), 0x00FFFFFF),
            floatArrayOf(0f, 0.6f, 0.93f, 1f)
        )
        bw = 80f * d; sk = hf * 0.6f
        band.reset(); band.moveTo(sk, 0f); band.lineTo(sk + bw, 0f); band.lineTo(bw, hf); band.lineTo(0f, hf); band.close()
        shine.shader = LinearGradient(
            0f, 0f, bw + sk, 0f,
            intArrayOf(0x00FFFFFF, 0x55FFFFFF, 0x00FFFFFF), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
        )
    }

    override fun onDraw(canvas: Canvas) {
        val now = SystemClock.uptimeMillis()
        val dt = (now - lastT).coerceIn(0L, 64L); lastT = now
        if (state == S.DONE && now > doneUntil) { state = S.IDLE; label = "BOOST" }
        angle = (angle + (when (state) { S.BUSY -> 0.5f; S.DONE -> 0.1f; S.IDLE -> 0.08f }) * dt) % 360f
        val done = state == S.DONE
        val w = width.toFloat(); val h = height.toFloat(); val rr = 18f * d
        val pulse = (sin(now / 450.0) * 0.5 + 0.5).toFloat()
        val gc = if (done) 0xFF30D158.toInt() else 0xFFFF2D3F.toInt()

        // glow luar berdenyut
        for (i in 3 downTo 1) {
            glow.strokeWidth = i * 3f * d
            glow.color = Color.argb(((16f + 34f * pulse) / i).toInt().coerceIn(0, 255), Color.red(gc), Color.green(gc), Color.blue(gc))
            canvas.drawRoundRect(rect, rr, rr, glow)
        }
        fill.shader = if (done) green else red
        canvas.drawRoundRect(rect, rr, rr, fill)

        // kilau menyapu (lebih cepat saat membersihkan)
        val period = if (state == S.BUSY) 700L else 2600L
        val x = ((now % period) / period.toFloat()) * (w + bw + sk) - (bw + sk)
        canvas.save(); canvas.clipPath(clip); canvas.translate(x, 0f); canvas.drawPath(band, shine); canvas.restore()

        // cincin cahaya berputar
        sweep?.let { m.setRotate(angle, w / 2f, h / 2f); it.setLocalMatrix(m); border.shader = it }
        canvas.drawRoundRect(rect, rr, rr, border)

        // ikon vector + label
        val tw = text.measureText(label)
        val isz = 22f * d; val gap = 10f * d
        val x0 = (w - (isz + gap + tw)) / 2f
        val icon = if (done) check else bolt
        icon.setBounds(x0.toInt(), (h / 2f - isz / 2f).toInt(), (x0 + isz).toInt(), (h / 2f + isz / 2f).toInt())
        icon.draw(canvas)
        canvas.drawText(label, x0 + isz + gap, h / 2f - (text.ascent() + text.descent()) / 2f, text)

        if (isShown) postInvalidateOnAnimation()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> animate().scaleX(0.97f).scaleY(0.97f).setDuration(90).start()
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                animate().scaleX(1f).scaleY(1f).setDuration(260).setInterpolator(OvershootInterpolator(3f)).start()
        }
        return super.onTouchEvent(e)
    }
}
