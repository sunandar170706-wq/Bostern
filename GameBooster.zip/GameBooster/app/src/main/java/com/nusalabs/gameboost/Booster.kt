package com.nusalabs.gameboost

import android.app.ActivityManager
import android.app.NotificationManager
import android.content.Context
import android.content.pm.ApplicationInfo

object Booster {
    private const val PREFS = "booster"
    private const val KEY_FILTER = "prev_filter"

    /** Tutup proses background app non-sistem. Android bisa menghidupkannya lagi. */
    fun cleanRam(ctx: Context): Int {
        val am = ctx.getSystemService(ActivityManager::class.java)
        var count = 0
        ctx.packageManager.getInstalledApplications(0)
            .filter { (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 && it.packageName != ctx.packageName }
            .forEach { am.killBackgroundProcesses(it.packageName); count++ }
        return count
    }

    fun hasDndAccess(ctx: Context) =
        ctx.getSystemService(NotificationManager::class.java).isNotificationPolicyAccessGranted

    fun enableDnd(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        if (!nm.isNotificationPolicyAccessGranted) return
        val prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        // Simpan mode sebelumnya hanya jika belum ada (hindari menimpa dengan DND sendiri)
        if (!prefs.contains(KEY_FILTER)) prefs.edit().putInt(KEY_FILTER, nm.currentInterruptionFilter).apply()
        nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY)
    }

    fun restoreDnd(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        val prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (nm.isNotificationPolicyAccessGranted && prefs.contains(KEY_FILTER)) {
            nm.setInterruptionFilter(prefs.getInt(KEY_FILTER, NotificationManager.INTERRUPTION_FILTER_ALL))
        }
        prefs.edit().remove(KEY_FILTER).apply()
    }
}
