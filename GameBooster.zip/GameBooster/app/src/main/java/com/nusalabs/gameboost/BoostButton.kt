package com.nusalabs.gameboost

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.SweepGradient
import android.graphics.Typeface
import android.os.SystemClock
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/** Tombol BOOST hexagon: glow berdenyut, cincin cahaya berputar, berubah hijau saat selesai. */
class BoostButton @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null) : View(context, attrs) {

    private enum class S { IDLE, BUSY, DONE }

    private val d = resources.displayMetrics.density
    private var state = S.IDLE
    private var doneUntil = 0L
    private var sub = "TAP TO OPTIMIZE"
    private var angle = 0f
    private var lastT = SystemClock.uptimeMillis()

    private val hexPath = Path()
    private val innerPath = Path()
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeJoin = Paint.Join.ROUND }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 3.5f * d; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textAlign = Paint.Align.CENTER; letterSpacing = 0.1f
        typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD_ITALIC)
    }
    private val subText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF8A8A95.toInt(); textAlign = Paint.Align.CENTER; letterSpacing = 0.15f
        typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
    }
    private var sweep: SweepGradient? = null
    private val m = Matrix()
    private var cx = 0f
    private var cy = 0f
    private var rad = 0f

    fun start() { state = S.BUSY; sub = "CLEANING..." }

    fun finish(result: String) {
        state = S.DONE; sub = result
        doneUntil = SystemClock.uptimeMillis() + 2200L
    }

    private fun hex(p: Path, r: Float) {
        p.reset()
        for (i in 0 until 6) {
            val a = Math.toRadians(60.0 * i - 90.0)
            val x = cx + (r * cos(a)).toFloat(); val y = cy + (r * sin(a)).toFloat()
            if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
        }
        p.close()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        cx = w / 2f; cy = h / 2f
        rad = min(h / 2f, w / 1.7320508f) * 0.88f
        hex(hexPath, rad); hex(innerPath, rad * 0.82f)
        fill.shader = RadialGradient(cx, cy, rad, 0xFF3A0A14.toInt(), 0xFF0A0306.toInt(), Shader.TileMode.CLAMP)
        sweep = SweepGradient(
            cx, cy,
            intArrayOf(0x00FF1744, 0x00FF1744, 0xFFFF1744.toInt(), 0xFFFFFFFF.toInt()),
            floatArrayOf(0f, 0.55f, 0.95f, 1f)
        )
        text.textSize = rad * 0.30f
        subText.textSize = rad * 0.115f
        text.setShadowLayer(10f * d, 0f, 0f, 0xFFFF1744.toInt())
    }

    override fun onDraw(canvas: Canvas) {
        val now = SystemClock.uptimeMillis()
        val dt = (now - lastT).coerceIn(0L, 64L); lastT = now
        if (state == S.DONE && now > doneUntil) { state = S.IDLE; sub = "TAP TO OPTIMIZE" }
        val speed = when (state) { S.BUSY -> 0.9f; S.DONE -> 0.25f; S.IDLE -> 0.12f }
        angle = (angle + speed * dt) % 360f
        val pulse = (sin(now / 450.0) * 0.5 + 0.5).toFloat()
        val col = if (state == S.DONE) 0xFF3DFFA6.toInt() else 0xFFFF1744.toInt()

        // glow luar (berlapis)
        for (i in 3 downTo 1) {
            val a = ((20f + 35f * pulse) / i).toInt().coerceIn(0, 255)
            line.color = Color.argb(a, Color.red(col), Color.green(col), Color.blue(col))
            line.strokeWidth = i * 4f * d
            canvas.drawPath(hexPath, line)
        }
        canvas.drawPath(hexPath, fill)
        line.strokeWidth = d
        line.color = Color.argb(0x55, Color.red(col), Color.green(col), Color.blue(col))
        canvas.drawPath(innerPath, line)
        line.strokeWidth = 2.2f * d
        line.color = col
        canvas.drawPath(hexPath, line)

        // cincin cahaya berputar
        val sw = sweep
        if (sw != null) {
            m.setRotate(angle, cx, cy); sw.setLocalMatrix(m)
            ring.shader = sw
            ring.alpha = if (state == S.DONE) 80 else 255
            canvas.drawPath(hexPath, ring)
        }

        // label
        val label = if (state == S.DONE) "DONE" else "BOOST"
        val ty = cy - (text.ascent() + text.descent()) / 2f - rad * 0.08f
        canvas.drawText(label, cx, ty, text)
        canvas.drawText(sub, cx, cy + rad * 0.45f, subText)

        if (isShown) postInvalidateOnAnimation()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> animate().scaleX(0.94f).scaleY(0.94f).setDuration(90).start()
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> animate().scaleX(1f).scaleY(1f).setDuration(140).start()
        }
        return super.onTouchEvent(e)
    }
}
