package com.nusalabs.gameboost

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PathMeasure
import android.os.SystemClock
import android.util.AttributeSet
import android.widget.LinearLayout
import kotlin.random.Random

/** Kartu dengan sudut terpotong (chamfer) ala ROG + cahaya merah yang berjalan mengelilingi tepinya. */
class RogCard @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null) : LinearLayout(context, attrs) {

    private val d = resources.displayMetrics.density
    private val cut = 10f * d
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = 0xE60E0E12.toInt() }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = d; color = 0xFF2A2A30.toInt() }
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 5f * d; strokeCap = Paint.Cap.ROUND; color = 0x40FF1744
    }
    private val core = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 1.6f * d; strokeCap = Paint.Cap.ROUND; color = 0xFFFF4D6D.toInt()
    }
    private val path = Path()
    private val seg = Path()
    private val pm = PathMeasure()
    private val offset = Random.nextFloat()

    init { setWillNotDraw(false) }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        val wf = w.toFloat(); val hf = h.toFloat()
        path.reset()
        path.moveTo(cut, 0f); path.lineTo(wf, 0f); path.lineTo(wf, hf - cut)
        path.lineTo(wf - cut, hf); path.lineTo(0f, hf); path.lineTo(0f, cut); path.close()
        pm.setPath(path, false)
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawPath(path, fill)
        canvas.drawPath(path, stroke)
        super.onDraw(canvas)
    }

    override fun dispatchDraw(canvas: Canvas) {
        super.dispatchDraw(canvas)
        val len = pm.length
        if (width > 0 && len > 0f) {
            val phase = (((SystemClock.uptimeMillis() % 3600L) / 3600f) + offset) % 1f
            val s = phase * len; val l = len * 0.16f
            seg.reset()
            if (s + l <= len) {
                pm.getSegment(s, s + l, seg, true)
            } else {
                pm.getSegment(s, len, seg, true)
                pm.getSegment(0f, s + l - len, seg, false)
            }
            canvas.drawPath(seg, glow)
            canvas.drawPath(seg, core)
        }
        if (isShown) postInvalidateOnAnimation()
    }
}
