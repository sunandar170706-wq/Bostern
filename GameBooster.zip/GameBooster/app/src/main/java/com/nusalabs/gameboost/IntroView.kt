package com.nusalabs.gameboost

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.util.AttributeSet
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.min
import kotlin.math.sin

/** Animasi pembuka: logo muncul dengan glow, garis scan merah, lalu tulisan "BY nandar". */
class IntroView @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null) : View(context, attrs) {

    private val d = resources.displayMetrics.density
    private val logo: Bitmap? = BitmapFactory.decodeResource(resources, R.drawable.logo_bostern)
    private var p = 0f
    private var anim: ValueAnimator? = null
    private var finished = false

    private val logoPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG)
    private val scan = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFF1744.toInt(); strokeWidth = 2f * d }
    private val red = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFF1744.toInt(); textSize = 19f * d; letterSpacing = 0.25f
        typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD_ITALIC)
    }
    private val white = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFFFFF.toInt(); textSize = 19f * d; letterSpacing = 0.25f
        typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD_ITALIC)
    }
    private val tag = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF8A8A95.toInt(); textSize = 11f * d; letterSpacing = 0.35f; textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
    }
    private val bar = Paint(Paint.ANTI_ALIAS_FLAG)
    private val dest = RectF()
    private var glowR = 0f

    private fun smooth(x: Float): Float { val t = x.coerceIn(0f, 1f); return t * t * (3f - 2f * t) }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        glowR = min(w, h) * 0.6f
        glow.shader = RadialGradient(0f, 0f, glowR, 0x66FF1744, 0x00FF1744, Shader.TileMode.CLAMP)
    }

    /** Jalankan intro. [onStartExit] dipanggil begitu intro mulai memudar. */
    fun play(onStartExit: () -> Unit) {
        isClickable = true                       // tahan sentuhan selama intro tampil
        val a = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 2300
            interpolator = LinearInterpolator()
            addUpdateListener { p = it.animatedValue as Float; invalidate() }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    if (finished) return
                    finished = true
                    onStartExit()
                    animate().alpha(0f).setDuration(350).withEndAction { visibility = GONE }.start()
                }
            })
        }
        anim = a
        setOnClickListener { a.end() }           // ketuk untuk lewati
        a.start()
    }

    override fun onDetachedFromWindow() { anim?.cancel(); super.onDetachedFromWindow() }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        c.drawColor(0xFF050507.toInt())
        val cx = w / 2f; val cy = h * 0.40f
        val e = smooth(p / 0.40f)

        // glow di belakang logo
        glow.alpha = (255 * e * (0.8f + 0.2f * sin(p * 14f))).toInt().coerceIn(0, 255)
        val gs = 0.6f + 0.4f * e
        c.save(); c.translate(cx, cy); c.scale(gs, gs); c.drawCircle(0f, 0f, glowR, glow); c.restore()

        // logo
        val size = min(w, h) * 0.62f * (0.7f + 0.3f * e)
        dest.set(cx - size / 2, cy - size / 2, cx + size / 2, cy + size / 2)
        logo?.let {
            logoPaint.alpha = (255 * e).toInt().coerceIn(0, 255)
            c.drawBitmap(it, null, dest, logoPaint)
        }

        // garis scan merah menyapu logo
        if (p in 0.30f..0.78f) {
            val s = (p - 0.30f) / 0.48f
            val y = dest.top + dest.height() * s
            c.save(); c.clipRect(dest)
            for (i in 0..8) {
                scan.alpha = (170 - i * 18).coerceAtLeast(0)
                val yy = y - i * 3f * d
                c.drawLine(dest.left, yy, dest.right, yy, scan)
            }
            c.restore()
        }

        // "BY nandar"
        val ta = smooth((p - 0.55f) / 0.25f)
        if (ta > 0f) {
            val a1 = "BY"; val b1 = "nandar"; val gap = 8f * d
            val wa = red.measureText(a1); val wb = white.measureText(b1)
            val x0 = cx - (wa + gap + wb) / 2f
            val y0 = dest.bottom + 52f * d
            red.alpha = (255 * ta).toInt(); white.alpha = (255 * ta).toInt(); tag.alpha = (255 * ta).toInt()
            c.drawText(a1, x0, y0, red)
            c.drawText(b1, x0 + wa + gap, y0, white)
            c.drawText("GAME BOOSTER", cx, y0 + 26f * d, tag)
        }

        // progress tipis di bawah
        val bw = w * 0.5f; val bx = (w - bw) / 2f; val by = h - 64f * d
        bar.color = 0xFF1B1B21.toInt(); c.drawRect(bx, by, bx + bw, by + 2f * d, bar)
        bar.color = 0xFFFF1744.toInt(); c.drawRect(bx, by, bx + bw * p, by + 2f * d, bar)
    }
}
