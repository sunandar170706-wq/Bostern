package com.nusalabs.gameboost

/** Data donasi & kontak. Ubah di sini kalau ada yang berganti. */
object Donate {
    const val DANA = "087886431406"
    const val TIKTOK = "kanjjjutttt_"
    const val WA = "087886431406"
    val WA_INTL: String get() = "62" + WA.removePrefix("0")
}
