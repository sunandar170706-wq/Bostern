package com.nusalabs.gameboost

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import android.os.SystemClock
import android.util.AttributeSet
import android.view.View
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.sqrt

/** Background bergaya ROG: serat karbon, grid hexagon berdenyut, dan kilatan merah diagonal. */
class RogBackground @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null) : View(context, attrs) {

    private val d = resources.displayMetrics.density
    private var base: Bitmap? = null
    private var hex: Bitmap? = null          // setengah resolusi, di-scale 2x saat digambar
    private val hexPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val streakPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val streakPath = Path()
    private val band = Path()
    private var streakW = 0f

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        base?.recycle(); hex?.recycle(); base = null; hex = null
        if (w <= 0 || h <= 0) return
        base = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888).also { drawBase(Canvas(it), w, h) }
        val hw = max(1, w / 2); val hh = max(1, h / 2)
        hex = Bitmap.createBitmap(hw, hh, Bitmap.Config.ARGB_8888).also { drawHex(Canvas(it), hw, hh) }
        streakW = 90f * d
        streakPaint.shader = LinearGradient(
            0f, 0f, streakW, 0f,
            intArrayOf(0x00FF1744, 0x33FF1744, 0x00FF1744), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
        )
    }

    private fun drawBase(c: Canvas, w: Int, h: Int) {
        val wf = w.toFloat(); val hf = h.toFloat()
        c.drawColor(0xFF050507.toInt())
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        // serat karbon diagonal
        p.color = 0xFF0C0C11.toInt(); p.strokeWidth = 3f * d
        val step = 7f * d
        var k = -hf
        while (k < wf) { c.drawLine(k, 0f, k + hf, hf, p); k += step }
        // cahaya merah di pojok kiri-atas & kanan-bawah
        p.shader = RadialGradient(0f, 0f, wf * 0.9f, 0x55B3001E, 0x00B3001E, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, wf, hf, p)
        p.shader = RadialGradient(wf, hf, wf * 0.9f, 0x44B3001E, 0x00B3001E, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, wf, hf, p)
        // vignette
        p.shader = RadialGradient(wf / 2f, hf / 2f, max(wf, hf) * 0.75f, 0x00000000, 0x99000000.toInt(), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, wf, hf, p)
        p.shader = null
        // garis aksen merah
        p.style = Paint.Style.STROKE; p.strokeWidth = 1.5f * d; p.color = 0x66FF1744
        for (i in 0..2) {
            val o = i * 18f * d
            c.drawLine(wf - 140f * d + o, 0f, wf, 140f * d - o, p)
            c.drawLine(0f, hf - 160f * d + o, 160f * d - o, hf, p)
        }
    }

    private fun drawHex(c: Canvas, w: Int, h: Int) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 0.75f * d }
        val r = 15f * d
        val dx = sqrt(3f) * r; val dy = 1.5f * r
        val path = Path()
        var row = 0; var y = 0f
        while (y < h + r) {
            var x = if (row % 2 == 0) 0f else dx / 2f
            while (x < w + dx) {
                val d1 = hypot(x, y) / (w * 0.75f)
                val d2 = hypot(w - x, h - y) / (w * 0.75f)
                val f = max(1f - d1, 1f - d2).coerceIn(0f, 1f)
                if (f > 0.02f) {
                    p.color = Color.argb((255 * f * f).toInt().coerceIn(0, 255), 255, 23, 68)
                    path.reset()
                    for (i in 0 until 6) {
                        val a = Math.toRadians(60.0 * i - 30.0)
                        val px = x + (r * cos(a)).toFloat(); val py = y + (r * sin(a)).toFloat()
                        if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
                    }
                    path.close(); c.drawPath(path, p)
                }
                x += dx
            }
            y += dy; row++
        }
    }

    override fun onDraw(canvas: Canvas) {
        val b = base ?: return
        val w = width.toFloat(); val h = height.toFloat()
        val t = (SystemClock.uptimeMillis() % 100000L) / 1000f
        canvas.drawBitmap(b, 0f, 0f, null)

        val hx = hex
        if (hx != null) {
            // grid hexagon berdenyut
            hexPaint.alpha = (255 * (0.35f + 0.25f * sin(t * 1.6f))).toInt().coerceIn(0, 255)
            canvas.save(); canvas.scale(2f, 2f); canvas.drawBitmap(hx, 0f, 0f, hexPaint); canvas.restore()
            // pita diagonal yang menyapu & menyalakan hexagon
            val sl = h * 0.5f; val bw = 110f * d
            val sx = ((t / 5f) % 1f) * (w + sl + bw) - bw
            band.reset()
            band.moveTo(sx, 0f); band.lineTo(sx + bw, 0f); band.lineTo(sx + bw - sl, h); band.lineTo(sx - sl, h); band.close()
            hexPaint.alpha = 255
            canvas.save(); canvas.clipPath(band); canvas.scale(2f, 2f); canvas.drawBitmap(hx, 0f, 0f, hexPaint); canvas.restore()
        }

        // kilatan merah diagonal
        if (streakW > 0f) {
            val sl = h * 0.5f
            for (i in 0..2) {
                val ph = (t / (7f + i * 2f) + i * 0.37f) % 1f
                val x = ph * (w + sl + streakW) - streakW
                canvas.save(); canvas.translate(x, 0f)
                streakPath.reset()
                streakPath.moveTo(0f, 0f); streakPath.lineTo(streakW, 0f)
                streakPath.lineTo(streakW - sl, h); streakPath.lineTo(-sl, h); streakPath.close()
                canvas.drawPath(streakPath, streakPaint)
                canvas.restore()
            }
        }
        if (isShown) postInvalidateOnAnimation()
    }
}
