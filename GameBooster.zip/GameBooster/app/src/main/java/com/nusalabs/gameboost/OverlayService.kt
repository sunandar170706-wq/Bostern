package com.nusalabs.gameboost

import android.app.ActivityManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.text.Spannable
import android.text.SpannableStringBuilder
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import java.util.Locale
import kotlin.math.abs

class OverlayService : Service() {

    private var wm: WindowManager? = null
    private var root: View? = null
    private var info: TextView? = null
    private var collapsed = false
    private val handler = Handler(Looper.getMainLooper())

    private val ticker = object : Runnable {
        override fun run() {
            info?.text = buildInfo(collapsed)
            handler.postDelayed(this, 1000)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()                       // DND dikembalikan di onDestroy()
            return START_NOT_STICKY
        }
        startAsForeground()
        // Izin overlay bisa dicabut saat service di-restart sistem -> jangan crash
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY }
        if (root == null) addOverlay()
        return START_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("booster", "BOSTERn", NotificationManager.IMPORTANCE_LOW))
        val stopIntent = PendingIntent.getService(
            this, 0, Intent(this, OverlayService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        val notif: Notification = NotificationCompat.Builder(this, "booster")
            .setSmallIcon(R.drawable.ic_stat_boost)
            .setColor(0xFFFF1744.toInt())
            .setContentTitle("BOSTERn aktif")
            .setContentText("Overlay monitor berjalan • BY nandar")
            .addAction(0, "Stop", stopIntent)
            .setOngoing(true)
            .build()
        val type = when {
            Build.VERSION.SDK_INT >= 34 -> ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            Build.VERSION.SDK_INT >= 29 -> ServiceInfo.FOREGROUND_SERVICE_TYPE_MANIFEST
            else -> 0
        }
        ServiceCompat.startForeground(this, 1, notif, type)
    }

    private fun addOverlay() {
        val manager = getSystemService(WINDOW_SERVICE) as WindowManager
        wm = manager
        val d = resources.displayMetrics.density

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            alpha = 0.9f
            background = GradientDrawable().apply {
                setColor(0xCC050507.toInt())
                setStroke((1 * d).toInt().coerceAtLeast(1), 0xAAFF1744.toInt())
                cornerRadius = 6 * d
            }
        }
        val tv = TextView(this).apply {
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-condensed", Typeface.NORMAL)
            textSize = 11f
            setPadding((10 * d).toInt(), (6 * d).toInt(), (4 * d).toInt(), (6 * d).toInt())
            text = buildInfo(false)
        }
        // Tombol tutup overlay (tidak menghentikan booster di notifikasi, hanya menutup kotak ini)
        val close = TextView(this).apply {
            text = "✕"
            setTextColor(0xFFFF1744.toInt())
            textSize = 14f
            val pp = (10 * d).toInt()
            setPadding(pp, pp, pp, pp)
            setOnClickListener { stopSelf() }
        }
        box.addView(tv); box.addView(close)

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 20; y = 120 }

        // Geser dengan jari; ketuk (tanpa geser) = ringkas / lebarkan
        val slop = 8 * d
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
        tv.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - tx; val dy = e.rawY - ty
                    if (abs(dx) > slop || abs(dy) > slop) moved = true
                    if (moved) {
                        lp.x = sx + dx.toInt(); lp.y = sy + dy.toInt()
                        runCatching { manager.updateViewLayout(box, lp) }
                    }
                }
                MotionEvent.ACTION_UP -> if (!moved) {
                    collapsed = !collapsed
                    tv.text = buildInfo(collapsed)
                    runCatching { manager.updateViewLayout(box, lp) }
                }
            }
            true
        }
        val added = runCatching { manager.addView(box, lp) }.isSuccess
        if (!added) { stopSelf(); return }
        root = box; info = tv
        handler.post(ticker)
    }

    private fun buildInfo(compact: Boolean): CharSequence {
        val am = getSystemService(ActivityManager::class.java)
        val mi = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        val usedMb = (mi.totalMem - mi.availMem) / 1048576
        val totalMb = mi.totalMem / 1048576
        val b = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = b?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = (b?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100).coerceAtLeast(1)
        val temp = (b?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
        val pct = if (level >= 0) level * 100 / scale else 0

        val head = "BOSTERn"
        val sb = SpannableStringBuilder(head)
        sb.setSpan(ForegroundColorSpan(0xFFFF1744.toInt()), 0, head.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        sb.setSpan(StyleSpan(Typeface.BOLD_ITALIC), 0, head.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        if (compact) {
            val ramPct = if (mi.totalMem > 0) (mi.totalMem - mi.availMem) * 100 / mi.totalMem else 0
            sb.append("  RAM $ramPct%")
            return sb
        }
        sb.append("\nRAM $usedMb/$totalMb MB")
        sb.append("\nBAT $pct%  ").append(String.format(Locale.US, "%.1f", temp)).append("°C")
        return sb
    }

    override fun onDestroy() {
        handler.removeCallbacks(ticker)
        root?.let { v -> runCatching { wm?.removeView(v) } }
        root = null; info = null
        Booster.restoreDnd(this)             // kembalikan mode DND lama kapan pun service berhenti
        super.onDestroy()
    }

    companion object { const val ACTION_STOP = "com.nusalabs.gameboost.STOP" }
}
